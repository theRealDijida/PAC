#!/bin/bash
set -e
version="0.12.5.1"


echo 
echo "################################################"
echo "#                   Welcome   	             #"
echo "################################################"
echo 
echo "This script will update multiple PAC masternode to the latest version (${version})."
echo
#read -p 'Please provide the csv file path: ' csvpath
csvpath="nodes.csv"

echo "###############################"
echo "#  Installing Dependencies    #"		
echo "###############################"
echo ""
echo "Running this script on Ubuntu 16.04 LTS or newer is highly recommended."

if [ "$(uname)" == "Darwin" ]; then
    /usr/bin/ruby -e "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install)"
	brew reinstall python jq csvkit  
	brew install sshpass  
elif [ "$(expr substr $(uname -s) 1 5)" == "Linux" ]; then
    sudo apt-get -y update
	sudo apt-get -y install python-dev python-pip python-setuptools build-essential jq sshpass virtualenv csvkit
fi

csvjson "${csvpath}" > "data.json"
totalnodes=`jq '[.[] | select(has("ip")) ] | length' data.json`

if [ "${totalnodes}" == 0 ]; then
	echo "No  data found for the given csv file, please make sure format is correct and the headers are as follow: hostname,ip,password"
	exit
fi
i=0
lastPID=0
download=$(cat << EOF
		wget https://raw.githubusercontent.com/PACCommunity/PAC/master/pac-update.sh;
		chmod +x pac-update.sh;
		exit;
EOF
)
#installing=$(cat 
#)

#read -r -d '' download 
while [ $i -lt $totalnodes ]; do
	hostname=`jq ".[${i}] | .hostname" data.json`
	ip=`jq ".[${i}] | .ip" data.json`
	pswd=`jq ".[${i}] | .password" data.json`
	
	echo "Authenticating on node: ${ip//\"}" 
	echo "${pswd//\"} ssh ${hostname//\"}@${ip//\"}"
	echo "Updating node: ${ip}" 
	sshpass -p"${pswd//\"}" ssh "${hostname//\"}@${ip//\"}" $download
	(sshpass -p"${pswd//\"}" ssh "${hostname//\"}@${ip//\"}" << EOF
		echo "${pswd//\"}" | sudo -S ./pac-update.sh;
		exit;
EOF
) &
	#sleep 5
	lastPID=$!
	let i=i+1
done

#if [$lastPID -ne 0]; then

#fi
wait $lastPID
rm data.json

echo "#####################"
echo "#  Update finished  #"		
echo "#####################"
kill $$